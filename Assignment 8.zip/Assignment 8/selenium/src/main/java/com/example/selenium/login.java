package com.example.selenium;

import static org.testng.Assert.assertTrue;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class login {
	
	static ChromeDriver driver = null;
	
	@BeforeClass
    public static void setUpBeforeClass() throws Exception {
		System.setProperty("webdriver.chrome.driver", "C:\\chromedriver.exe");
		driver = new ChromeDriver();	//create chrome driver
		driver.manage().window().maximize();	//Maximize the window
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);	//set implicit wait as 20 Seconds
	}
	
	@Test
	public void test_LoginTest() throws InterruptedException {
		driver.get("http://wwww.amazon.com");	//Open amazon.com on the opened window
		driver.findElement(By.id("twotabsearchtextbox")).sendKeys("iPhone 8 Plus");	//Enter the string in search box
		driver.findElement(By.xpath("//*[@class=\"nav-search-submit nav-sprite\"]")).click();	//Click on search button
		driver.findElement(By.xpath("//*[@class=\"shopNow  shopNow--caretRight \"]")).click();	//Click on shop now
		driver.findElement(By.xpath("(//*[contains(@class,'style__addToCart')])[1]")).click();	//Add first phone to the cart
		driver.findElement(By.id("nav-cart")).click();	//Click on cart
		TimeUnit.MILLISECONDS.sleep(2000);
		assertTrue(driver.findElement(By.xpath("//*[@data-old-value=1]")).isDisplayed(),"Quantity not equal to 1");	//Check if the quantity is 1
		driver.findElement(By.xpath("//*[@class='sc-proceed-to-checkout']")).click();	//Click on Checkout
		assertTrue(driver.findElement(By.xpath("//h1")).getText().contains("Sign in"),"Sign in not available");	//Check if the flow is going to Sign in page or not
	}
	
	@AfterClass
    public static void CleanUp(){
        driver.quit();
    }
}
